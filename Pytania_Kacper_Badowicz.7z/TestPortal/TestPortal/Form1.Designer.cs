﻿namespace TestPortal
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            questionLabel = new Label();
            radioButtonA = new RadioButton();
            radioButtonB = new RadioButton();
            radioButtonC = new RadioButton();
            radioButtonD = new RadioButton();
            nextButton = new Button();
            previousButton = new Button();
            groupBox1 = new GroupBox();
            radioButtonE = new RadioButton();
            questionNumberLabel = new Label();
            end = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // questionLabel
            // 
            questionLabel.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            questionLabel.Location = new Point(141, 9);
            questionLabel.Name = "questionLabel";
            questionLabel.Size = new Size(516, 100);
            questionLabel.TabIndex = 0;
            questionLabel.Text = "Pytanie";
            questionLabel.TextAlign = ContentAlignment.TopCenter;
            // 
            // radioButtonA
            // 
            radioButtonA.AutoSize = true;
            radioButtonA.Location = new Point(17, 38);
            radioButtonA.Name = "radioButtonA";
            radioButtonA.Size = new Size(88, 34);
            radioButtonA.TabIndex = 1;
            radioButtonA.TabStop = true;
            radioButtonA.Text = "Odp 1";
            radioButtonA.UseVisualStyleBackColor = true;
            // 
            // radioButtonB
            // 
            radioButtonB.AutoSize = true;
            radioButtonB.Location = new Point(17, 78);
            radioButtonB.Name = "radioButtonB";
            radioButtonB.Size = new Size(88, 34);
            radioButtonB.TabIndex = 2;
            radioButtonB.TabStop = true;
            radioButtonB.Text = "Odp 2";
            radioButtonB.UseVisualStyleBackColor = true;
            // 
            // radioButtonC
            // 
            radioButtonC.AutoSize = true;
            radioButtonC.Location = new Point(17, 118);
            radioButtonC.Name = "radioButtonC";
            radioButtonC.Size = new Size(88, 34);
            radioButtonC.TabIndex = 3;
            radioButtonC.TabStop = true;
            radioButtonC.Text = "Odp 3";
            radioButtonC.UseVisualStyleBackColor = true;
            // 
            // radioButtonD
            // 
            radioButtonD.AutoSize = true;
            radioButtonD.Location = new Point(17, 158);
            radioButtonD.Name = "radioButtonD";
            radioButtonD.Size = new Size(88, 34);
            radioButtonD.TabIndex = 4;
            radioButtonD.TabStop = true;
            radioButtonD.Text = "Odp 4";
            radioButtonD.UseVisualStyleBackColor = true;
            // 
            // nextButton
            // 
            nextButton.BackColor = Color.DarkGray;
            nextButton.FlatAppearance.BorderColor = Color.Black;
            nextButton.FlatAppearance.BorderSize = 3;
            nextButton.FlatStyle = FlatStyle.Flat;
            nextButton.Font = new Font("Segoe UI", 72F, FontStyle.Bold, GraphicsUnit.Point);
            nextButton.Location = new Point(678, 9);
            nextButton.Name = "nextButton";
            nextButton.Size = new Size(110, 429);
            nextButton.TabIndex = 5;
            nextButton.Text = ">";
            nextButton.UseVisualStyleBackColor = false;
            nextButton.Click += nextButton_Click;
            // 
            // previousButton
            // 
            previousButton.BackColor = Color.DarkGray;
            previousButton.Enabled = false;
            previousButton.FlatAppearance.BorderColor = Color.Black;
            previousButton.FlatAppearance.BorderSize = 3;
            previousButton.FlatStyle = FlatStyle.Flat;
            previousButton.Font = new Font("Segoe UI", 72F, FontStyle.Bold, GraphicsUnit.Point);
            previousButton.Location = new Point(12, 9);
            previousButton.Name = "previousButton";
            previousButton.Size = new Size(110, 429);
            previousButton.TabIndex = 6;
            previousButton.Text = "<";
            previousButton.UseVisualStyleBackColor = false;
            previousButton.Click += previousButton_Click;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ActiveCaption;
            groupBox1.Controls.Add(radioButtonE);
            groupBox1.Controls.Add(radioButtonA);
            groupBox1.Controls.Add(radioButtonB);
            groupBox1.Controls.Add(radioButtonC);
            groupBox1.Controls.Add(radioButtonD);
            groupBox1.FlatStyle = FlatStyle.Flat;
            groupBox1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(281, 130);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(267, 243);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Odpowiedzi";
            // 
            // radioButtonE
            // 
            radioButtonE.AutoSize = true;
            radioButtonE.Location = new Point(17, 198);
            radioButtonE.Name = "radioButtonE";
            radioButtonE.Size = new Size(88, 34);
            radioButtonE.TabIndex = 5;
            radioButtonE.TabStop = true;
            radioButtonE.Text = "Odp 5";
            radioButtonE.UseVisualStyleBackColor = true;
            // 
            // questionNumberLabel
            // 
            questionNumberLabel.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            questionNumberLabel.Location = new Point(268, 376);
            questionNumberLabel.Name = "questionNumberLabel";
            questionNumberLabel.Size = new Size(280, 62);
            questionNumberLabel.TabIndex = 8;
            questionNumberLabel.Text = "Pytanie 0/1";
            questionNumberLabel.TextAlign = ContentAlignment.TopCenter;
            // 
            // end
            // 
            end.BackColor = Color.Gainsboro;
            end.Enabled = false;
            end.FlatAppearance.BorderColor = Color.Black;
            end.FlatStyle = FlatStyle.Flat;
            end.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            end.Location = new Point(569, 408);
            end.Name = "end";
            end.Size = new Size(103, 30);
            end.TabIndex = 9;
            end.Text = "Zakończ";
            end.UseVisualStyleBackColor = false;
            end.Click += end_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(end);
            Controls.Add(questionNumberLabel);
            Controls.Add(groupBox1);
            Controls.Add(previousButton);
            Controls.Add(nextButton);
            Controls.Add(questionLabel);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label questionLabel;
        private RadioButton radioButtonA;
        private RadioButton radioButtonB;
        private RadioButton radioButtonC;
        private RadioButton radioButtonD;
        private Button nextButton;
        private Button previousButton;
        private GroupBox groupBox1;
        private Label questionNumberLabel;
        private Button end;
        private RadioButton radioButtonE;
    }
}