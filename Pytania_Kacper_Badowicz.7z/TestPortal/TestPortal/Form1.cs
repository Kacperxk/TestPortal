using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace TestPortal
{
    public partial class Form1 : Form
    {
        private Quiz quiz;

        public Form1()
        {
            InitializeComponent();
            quiz = new Quiz();
            LoadQuestionsFromFile("questions.txt");
            DisplayCurrentQuestion();
        }

        private void LoadQuestionsFromFile(string fileName)
        {
            try
            {
                using (StreamReader sr = new StreamReader(fileName))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] parts = line.Split('|');
                        if (parts.Length >= 3)
                        {
                            string questionText = parts[0];
                            string[] choices = parts.Skip(1).Take(parts.Length - 2).ToArray();
                            string correctAnswer = parts[parts.Length - 1];
                            quiz.AddQuestion(new Question(questionText, choices, correctAnswer));
                        }
                        else
                        {
                            MessageBox.Show("Invalid question format: " + line);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error reading file: " + e.Message);
            }
        }

        private void DisplayCurrentQuestion()
        {
            Question currentQuestion = quiz.GetCurrentQuestion();
            questionLabel.Text = currentQuestion.Text;

            for (int i = 0; i < currentQuestion.Choices.Length; i++)
            {
                if (i == 0)
                    radioButtonA.Visible = true;
                else if (i == 1)
                    radioButtonB.Visible = true;
                else if (i == 2)
                    radioButtonC.Visible = true;
                else if (i == 3)
                    radioButtonD.Visible = true;
                else if (i == 4)
                    radioButtonE.Visible = true;

                switch (i)
                {
                    case 0:
                        radioButtonA.Text = currentQuestion.Choices[i];
                        break;
                    case 1:
                        radioButtonB.Text = currentQuestion.Choices[i];
                        break;
                    case 2:
                        radioButtonC.Text = currentQuestion.Choices[i];
                        break;
                    case 3:
                        radioButtonD.Text = currentQuestion.Choices[i];
                        break;
                    case 4:
                        radioButtonE.Text = currentQuestion.Choices[i];
                        break;
                }
            }

            for (int i = currentQuestion.Choices.Length; i < 5; i++)
            {
                switch (i)
                {
                    case 0:
                        radioButtonA.Visible = false;
                        break;
                    case 1:
                        radioButtonB.Visible = false;
                        break;
                    case 2:
                        radioButtonC.Visible = false;
                        break;
                    case 3:
                        radioButtonD.Visible = false;
                        break;
                    case 4:
                        radioButtonE.Visible = false;
                        break;
                }
            }

            questionNumberLabel.Text = $"Pytanie {quiz.CurrentQuestionIndex + 1}/{quiz.TotalQuestions}";

            string selectedAnswer = quiz.GetSelectedAnswer();
            if (!string.IsNullOrEmpty(selectedAnswer))
            {
                RadioButton selectedRadioButton = groupBox1.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Text.StartsWith(selectedAnswer));
                selectedRadioButton.Checked = true;
            }
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            previousButton.Enabled = true;
            quiz.CheckAnswer(GetSelectedAnswer());
            if (quiz.MoveToNextQuestion())
            {
                DisplayCurrentQuestion();
            }
            else
            {
                quiz.SetCurrentQuestionIndex(quiz.CurrentQuestionIndex - 1);
            }
            if (quiz.CurrentQuestionIndex == quiz.TotalQuestions - 1)
            {
                end.Enabled = true;
                nextButton.Enabled = false;
            }
            else
            {
                end.Enabled = false;
                nextButton.Enabled = true;
            }
        }

        private void previousButton_Click(object sender, EventArgs e)
        {
            nextButton.Enabled = true;
            end.Enabled = false;
            if (quiz.MoveToPreviousQuestion())
            {
                DisplayCurrentQuestion();
            }
            if (quiz.CurrentQuestionIndex == 0)
            {
                previousButton.Enabled = false;
            }
        }

        private string GetSelectedAnswer()
        {
            RadioButton selectedRadioButton = groupBox1.Controls.OfType<RadioButton>().FirstOrDefault(r => r.Checked);
            return selectedRadioButton?.Text.Substring(0, 1);
        }

        private void end_Click(object sender, EventArgs e)
        {
            quiz.CheckAnswer(GetSelectedAnswer());
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss");
            string fileName = $"testPortal_{timestamp}.txt";

            try
            {
                using (StreamWriter sw = new StreamWriter(fileName))
                {
                    sw.WriteLine("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n");
                    sw.WriteLine($"Data i godzina podj�cia testu: {timestamp}");
                    foreach (var question in quiz.Questions)
                    {
                        sw.WriteLine("-----------");
                        sw.WriteLine($"{question.Text}");
                        sw.WriteLine($"Wybrana odpowied�: {quiz.GetSelectedAnswer(question)}");
                        sw.WriteLine($"Poprawna odpowied�: {quiz.GetCorrectAnswer(question)}");
                        sw.WriteLine();
                    }
                    sw.WriteLine($"Wynik ko�cowy : {quiz.Score}/{quiz.TotalQuestions}");
                    sw.WriteLine("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
                }
                MessageBox.Show($"Zapisano do : {fileName}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"B��d: {ex.Message}");
            }

            MessageBox.Show($"Koniec! Tw�j wynik to: {quiz.Score}/{quiz.TotalQuestions}");
            Close();
        }
    }
}
