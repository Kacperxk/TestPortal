﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestPortal
{
    public class Quiz
    {
        private List<Question> questions;
        private Dictionary<int, string> selectedAnswers;
        private int currentQuestionIndex = 0;
        public int Score { get; private set; }

        public int CurrentQuestionIndex => currentQuestionIndex;
        public int TotalQuestions => questions.Count;

        public List<Question> Questions => questions;

        public Quiz()
        {
            questions = new List<Question>();
            selectedAnswers = new Dictionary<int, string>();
        }

        public void AddQuestion(Question question)
        {
            questions.Add(question);
        }

        public Question GetCurrentQuestion()
        {
            return questions[currentQuestionIndex];
        }

        public void SetCurrentQuestionIndex(int index)
        {
            currentQuestionIndex = index;
        }

        public bool MoveToNextQuestion()
        {
            currentQuestionIndex++;
            return currentQuestionIndex < questions.Count;
        }

        public bool MoveToPreviousQuestion()
        {
            if (currentQuestionIndex > 0)
            {
                currentQuestionIndex--;
                return true;
            }
            return false;
        }

        public void CheckAnswer(string selectedAnswer)
        {
            Question currentQuestion = questions[currentQuestionIndex];
            if (selectedAnswer != null && selectedAnswer == currentQuestion.Answer)
            {
                Score++;
            }
            currentQuestion.Answered = true;
            selectedAnswers[currentQuestionIndex] = selectedAnswer;
        }

        public string GetSelectedAnswer()
        {
            if (selectedAnswers.ContainsKey(currentQuestionIndex))
            {
                return selectedAnswers[currentQuestionIndex];
            }
            return null;
        }

        public string GetSelectedAnswer(Question question)
        {
            int index = questions.IndexOf(question);
            if (selectedAnswers.ContainsKey(index))
            {
                return selectedAnswers[index];
            }
            return null;
        }

        public string GetCorrectAnswer(Question question)
        {
            return question.Answer;
        }
    }
}
